var ping;

var mic;
var amp;
var scale = 1.0;
var sine;
var freq = 400;
var capture;
function preload() {
  ping = loadSound("MinecraftOOF.mp3");
}

function setup() {
  createCanvas(440, 440);
  background(1)
  mic = new p5.AudioIn();
  mic.start();
  amp = new p5.Amplitude();
  amp.setInput(mic);
  sine = new p5.SinOsc();
  sine.start();
  capture = createCapture();
  capture.hide();


}


function draw() {
  
var aspectRatio = capture.height/capture.width;
var h = width* aspectRatio;
image(capture, 0, 0, width, h);
filter(POSTERIZE, 3);



var hertz = map(mouseX, 0, width, 20.0, 440.0);
sine.freq(hertz);
stroke(204);
for (var x = 0; x < width; x++) {
var angle = map(x, 0, width, 0, TWO_PI * hertz);
var sinValue = sin(angle) * 120;
line(x, 0, x, height/2 + sinValue);
}



noStroke();
  fill(0, 10);
  rect(0, 0, width, height);

  scale = map(amp.getLevel(), 0, 1.0, 10, width);

  fill(255);
  ellipse(width/2, height/2, scale, scale);




  if (keyIsPressed === true) {
    fill(0);
    ping.play();
  } else {
    fill(200,0,0);
  }
  rect(170, 150, 100,100, 100, 100);
}