var img1;
var img2;
var font;
function preload() {
img1 = loadImage("openfield.jpg");
img2 = loadImage("cat.png");

}

function setup() {
createCanvas(400, 400);
textFont("consolas");
textFont("Odibee Sans");
fill(0);
stroke(255,0,0);
}
function draw() {
image(img1, 0, 0);
image(img2, 0, 100, mouseX * 1, mouseY * 1);

textSize(50);
text("Cats Are Fast", 25, 60);
text("Super Fast " ,300,275,150,125);

}
